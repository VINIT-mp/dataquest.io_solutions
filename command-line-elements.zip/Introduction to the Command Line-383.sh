## 3. The Prompt ##

/home/dq$