## 2. Introduction to Ndarrays ##

import numpy as np
data_ndarray=np.array([10,20,30,])