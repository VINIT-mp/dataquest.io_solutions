## 3. Populations and Samples ##

question_1 <- 'population'
question_2 <- 'population'
question_3 <- 'sample'
question_4 <- 'population'
question_5 <- 'sample'

## 4. Explore the Dataset ##

library(readr)
wnba<-read_csv("wnba.csv")