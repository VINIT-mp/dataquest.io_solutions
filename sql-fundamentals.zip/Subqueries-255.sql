## 2. Subqueries ##

select Major, Unemployment_rate from recent_grads
where Unemployment_rate<(select AVG(Unemployment_rate) from recent_grads)
ORDER BY Unemployment_rate ASC

## 3. Subquery in SELECT ##

SELECT CAST(COUNT(*) AS float) /CAST((SELECT COUNT(*) from  recent_grads) AS float) "proportion_abv_avg"
from  recent_grads
WHERE ShareWomen > (SELECT AVG(ShareWomen) from recent_grads)

## 5. Returning Multiple Results in Subqueries ##

SELECT Major, Major_category
FROM recent_grads
WHERE Major_category IN (SELECT Major_category FROM recent_grads
GROUP BY Major_category
ORDER BY SUM(Total) DESC
LIMIT 5)

## 6. Building Complex Subqueries ##

select AVG(cast (Sample_size as float)/cast(Total as float)) avg_ratio

from recent_grads


## 7. Practice Integrating A Subquery With The Outer Query ##

select Major, Major_category,  cast(Sample_size as float)/cast(Total as float) AS "ratio"
from recent_grads
where ratio >(select  avg(cast(Sample_size as float)/cast(Total as float)) as" avg_ratio" from recent_grads)

