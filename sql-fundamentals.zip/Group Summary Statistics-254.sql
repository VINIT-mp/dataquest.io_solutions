## 5. GROUP BY Visual Breakdown ##

SELECT Major_category, AVG(ShareWomen) FROM recent_grads
GROUP BY Major_category

## 8. Querying Virtual Columns With the HAVING Statement ##

SELECT Major_category, AVG(Low_wage_jobs)/AVG(Total) "share_low_wage" FROM recent_grads
GROUP BY Major_category
HAVING share_low_wage>.1


## 10. Rounding Results With the ROUND() Function ##

SELECT ROUND(ShareWomen, 4), Major_category from recent_grads
limit 10

## 11. Nesting functions ##

SELECT Major_category, ROUND(AVG(College_jobs)/Avg(Total), 3)"share_degree_jobs" from recent_grads
GROUP BY Major_category
HAVING share_degree_jobs <.3

## 12. Casting ##

SELECT Major_category, Cast(sum(Women) as Float)/Cast(SUM(total) as Float) "SW" FROM recent_grads
GROUP BY Major_category
ORDER BY SW
