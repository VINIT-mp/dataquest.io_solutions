## 6. The LIMIT Clause ##

select*FROM recent_grads limit 10



## 8. Filtering Rows Using WHERE ##

select major, ShareWomen from recent_grads
where ShareWomen <=0.5

## 9. Expressing Multiple Filter Criteria Using 'AND' ##

select major, Major_category, Median, ShareWomen from recent_grads
where ShareWomen >=0.5 and median >50000

## 10. Returning One of Several Conditions With OR ##

select major, median, Unemployed from recent_grads
where median >= 10000 or Unemployed<= 1000
limit 20

## 11. Grouping Operators With Parentheses ##

SELECT Major, Major_category, ShareWomen, Unemployment_rate from recent_grads

where(Major_category = "Engineering") and (ShareWomen >=0.5 or Unemployment_rate <0.051)

## 12. Ordering Results Using ORDER BY ##

SELECT Major, ShareWomen, Unemployment_rate FROM recent_grads
WHERE ShareWomen>=0.3 and Unemployment_rate <0.1
ORDER BY ShareWomen DESC

## 13. Practice Writing a Query ##

SELECT Major_category, Major, Unemployment_rate FROM recent_grads
WHERE (Major_category= "Engineering") OR (Major_category ="Physical Sciences")
ORDER by Unemployment_rate 