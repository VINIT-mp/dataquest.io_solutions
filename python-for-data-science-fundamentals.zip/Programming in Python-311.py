## 2. Programming in Python ##

8+42


## 3. The print() Command ##

print(40+4)
print(200-25)
print(14+3)

## 4. Python Syntax ##

print(30+10+40)
print(4)
print(-3)

## 5. Computer Programs ##

print(34+16)
print(34)
-34

## 6. Code Comments ##

# INITIAL CODE
print(34 + 16)
print(34)
print(-34)

## 7. Arithmetical Operations ##

print(16*10)
print(48/5)
print(5**3)